<!--Template file, used to make the footer and for the html layouts closing tags-->
</main>
		<footer>
			&copy; Fotheby's 2022
		</footer>
	</body>
</html>
