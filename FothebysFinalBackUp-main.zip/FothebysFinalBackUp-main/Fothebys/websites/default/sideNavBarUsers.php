<!--This is to streamline code and reduce repetition--> 
<!--This is seperate to the other nav bar as not all pages require this side bar-->
<nav>
	<ul>
		<li><a href="userHub.php">Account Details</a></li>
		<li><a href="previousPurchases.php">Previous Purchases</a></li>
		<li><a href="seatBookings.php">Book a Seat</a></li>
		<li><a href="bookings.php">Book an Appraisal (ComingS Soon)</a></li>
		<li><a href="logout.php">Log Out</a></li>
	</ul>
</nav>